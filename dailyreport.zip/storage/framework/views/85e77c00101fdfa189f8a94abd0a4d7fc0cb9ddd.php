

<?php $__env->startSection('content'); ?>
<div class="col-12">
  <div class="col-12 col-md-8 col-lg-6 mx-auto">
    <table class="table table-striped">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>รายงานประจำวัน</th>
                    <th>วันที่ทำงาน</th>

                </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="" data-toggle="modal" data-target="#No<?php echo e($report_row->ID); ?>">
                    <th><?php echo e($loop->index + 1); ?></th>
                    <td><?php echo e($report_row->Name); ?></td>
                    <td><?php echo e($report_row->workDate->format('d-m-Y')); ?></td>
                </tr>



                <div class="modal" id="No<?php echo e($report_row->ID); ?>" aria-hidden="true" style="display: none;">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title"><?php echo e($report_row->Name); ?></h5>
                            <h5 class="modal-title"><?php echo e($report_row->workDate->format('d-m-Y')); ?></h5>
                            <button class="close" data-dismiss="modal">×</button>
                          </div>
                          <div class="modal-body">
                            <form>
                                <div class="form-row mx-auto col-6">
                                  <div class="form-group col mx-auto">
                                      <?php echo e($report_row->Work1->whereNotNull('Work1')); ?>

                                  </div>
                                </div>
                            </form>
                          </div>
                          <div class="modal-footer">
                            <button class="btn btn-primary" data-dismiss="modal">Login</button>
                          </div>
                        </div>
                      </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DailyReport\resources\views/DailyReport/index.blade.php ENDPATH**/ ?>